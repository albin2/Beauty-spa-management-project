<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Validator extends Model
{
    //
}
