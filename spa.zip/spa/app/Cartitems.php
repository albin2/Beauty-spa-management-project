<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cartitems extends Model
{
    protected $table = 'cartitems';
    
    protected $fillable = [
        'cartid','ptoductid','count',
    ];
}
