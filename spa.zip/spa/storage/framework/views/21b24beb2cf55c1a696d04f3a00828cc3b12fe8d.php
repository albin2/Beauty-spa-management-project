<?php $__env->startSection('content'); ?>

<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">

        <?php $__env->startComponent('adminpages.navbar'); ?>
        <?php echo $__env->renderComponent(); ?>
        <!-- Left side column. contains the logo and sidebar -->

        <?php $__env->startComponent('adminpages.sidebar'); ?>
        <?php echo $__env->renderComponent(); ?>
        
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <form method="POST" class="oh-autoval-form" enctype="multipart/form-data" action="<?php echo e(route('updateproduct')); ?>" onsubmit="return">
                <?php echo csrf_field(); ?>
                <?php if(isset($info)): ?>
                <div class="alert-info alert">
                 <?php echo e($info); ?>

                </div>
              <?php endif; ?>
                <class="box-body">

                    <center>
                        <h2><B>UPDATE PRODUCT STOCK</B></h2>
                    </center>
                    <div style="margin-left:100px;margin-right:100px;margin-top:20px;background-color: #e7e4e7;">

                        
                            
                            <label>
                                <h4><b>PRODUCT NAME : <?php echo e($datas[0]->productname); ?> </b></h4>
                            </label>
                        
                            <div class="form-group">
                                <label>
                                    <h4><b>CURRENT STOCK : <?php echo e($datas[0]->stock); ?> </b></h4>
                                </label>
                            </div>

                            <div class="form-group">
                                <label>
                                    <h4><b>NEW STOCK</b></h4>
                                </label>
                                <input type="text" class="form-control av-posnumber" av-message="positive number" name="stock" placeholder="stock details">
                            </div>
                             <div style="margin-left:400px;">
                             <input hidden name="id" value="<?php echo e($datas[0]->id); ?>">
                             <input hidden name="cstock" value="<?php echo e($datas[0]->stock); ?>">
                                <button type="submit" name="submit" class="btn btn-primary">UPDATE STOCK</button>
                    </div>
                   </div>
               </div>

          </form>


    </div>
    <!-- /.content-wrapper -->
    </div>
    <!-- ./wrapper -->

    <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>