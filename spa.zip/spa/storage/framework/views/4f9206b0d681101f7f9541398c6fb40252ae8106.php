<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

<?php $__env->startComponent('agentpages.navbar'); ?>
 <?php echo $__env->renderComponent(); ?>
  <!-- Left side column. contains the logo and sidebar -->
 
  <?php $__env->startComponent('agentpages.sidebar'); ?>
 <?php echo $__env->renderComponent(); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
</style>
</head>
<body>

<center><h3><b><class="box-title">PRODUCT BOOKING DETAILS</b></h3></center>


<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search ......." title="Type in a name">

<table id="myTable">
<?php if(isset($info)): ?>
                <div class="alert-info alert">
                 <?php echo e($info); ?>

                </div>
              <?php endif; ?>
  <tr class="header"> 
                 <th>BOOOKING DATE</th>
                  <th>BOOKING ID</th>
                  <th>USER NAME</th>
                  <th>SHIPPING ADDRESS</th>
                  <th>LAND_MARK</th> 
                  <th>STATUS</th>
                  <th>*</th>


  </tr>

                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                  <td><?php echo e($row->updated_at); ?></td>
                  <td>BKPAPAYA<?php echo e($row->cartid); ?></td>
                  <td><?php echo e($row->fname); ?> <?php echo e($row->lname); ?></td>
                  <td><?php echo e($row->firstname); ?> <?php echo e($row->lastname); ?><br>
                    <?php echo e($row->address); ?><br>
                      <?php echo e($row->post); ?><br>
                      <?php echo e($row->pincode); ?>


                  </td>
                  <td><?php echo e($row->landmark); ?></td>
                  
                  <td> <?php if($row->satus==0): ?>
                  <span style="color:red"><b> CANCELLED</b></span>
                    <?php elseif($row->satus==2): ?>
                    <span style="color:blue"> <b> BOOKED</b></span>
                    <?php elseif($row->satus==3): ?>
                    <span style="color:brown"><b> SHIPPED</b></span>
                    <?php elseif($row->satus==4): ?>
                    <span style="color:green"><b> DELIVERED </span>
                    <?php endif; ?> 
                  </td>
                  
                  <td>
                  
                    <form action="<?php echo e(route('agentviewdetailsproduct')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <input hidden name="status" value="<?php echo e($row->satus); ?>">
                      <input hidden name="tmnt" value="<?php echo e($row->totalamount); ?>">
                        <input hidden name="id" value="<?php echo e($row->cartid); ?>">
                        <button type="submit"  class="btn btn-primary" >VIEW DETAILS</button>
                    </form>
                   
                  </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
   </table>

<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

</body>
</html>

    <!-- Main content -->
    
    <!-- /.content -->
  </div>
  <?php $__env->stopSection(); ?>
 
 
 
 
 
 
 
 
 
 
 
 
 
 

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>