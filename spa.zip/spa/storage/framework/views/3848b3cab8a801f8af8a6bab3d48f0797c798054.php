<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

 <?php $__env->startComponent('adminpages.navbar'); ?>
 <?php echo $__env->renderComponent(); ?>
  <!-- Left side column. contains the logo and sidebar -->
 
<?php $__env->startComponent('adminpages.sidebar'); ?>
 <?php echo $__env->renderComponent(); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->

 
    <html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
</style>
</head>
<body>

<center><h3><b><class="box-title">PRODUCT BOOKING DETAILS</b></h3></center>



<table id="myTable">
<?php if(isset($info)): ?>
                <div class="alert-info alert">
                 <?php echo e($info); ?>

                </div>
              <?php endif; ?>
           
  <tr class="header"> 
                 <th>PRODUCT NAME</th>
                 <th>QUANTITY</th>
                  <th>COUNT</th>
                  <th>PRICE</th>
                  <th>SUBTOTAL</th>
                  
                  
  </tr>
  

                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                  <td><?php echo e($row->productname); ?></td>
                  <td><?php echo e($row->quantity); ?>g</td>
                  <td><?php echo e($row->count); ?></td>
                  <td><?php echo e($row->price); ?> </td>
                  <td><?php echo e($row->price*$row->count); ?> </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td><b>Total Amount</b></td>
                      <td><span style="color:gray"><b><?php echo e($total); ?><b></span></td>
                  </tr>
                  <tr>
                  <td></td>    
                  <td></td>  
                  <td></td>  
                      
                  <td>CURRENT STAUS:</td>  
                  <td>
               
                    <?php if($sta==2): ?>
                    <span style="color:blue"> <b> BOOKED</b></span>
                    <?php elseif($sta==0): ?>
                    <span style="color:red"><b> CANCELLED</b></span>
                    <?php elseif($sta==3): ?>
                    <span style="color:brown"><b> SHIPPED</b></span>
                    <?php elseif($sta==4): ?>
                      <span style="color:green"><b> DELIVERED </span>
                    <?php endif; ?> 
      
                  </td> 
                  </tr>
                  <tr>
                  <?php if($sta==2): ?> 
                  <td></td>    
                  <td></td>  
                  <td></td>  
                  
                  <td>Change status:</td>  
                  <td>
               
                 
                    <form action="<?php echo e(route('shippedproduct')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input hidden name="id" value="<?php echo e($row->cartid); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="submit"  class="btn btn-primary" >SHIPPED</button>
                    </form>
                   
                    <?php endif; ?> 
      
                  </td> 
                  </tr>
                 
                
                
   </table>

<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

</body>
</html>

    <!-- Main content -->
    
    <!-- /.content -->
  </div>
  <?php $__env->stopSection(); ?>
 
 
 
 
 
 
 
 
 
 
 
 
 
 

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>