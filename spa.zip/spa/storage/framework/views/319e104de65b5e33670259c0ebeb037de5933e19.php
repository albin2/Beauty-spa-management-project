<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

 <?php $__env->startComponent('adminpages.navbar'); ?>
 <?php echo $__env->renderComponent(); ?>
  <!-- Left side column. contains the logo and sidebar -->
 
  <?php $__env->startComponent('adminpages.sidebar'); ?>
 <?php echo $__env->renderComponent(); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

  <form class="login100-form validate-form" method="POST" action="<?php echo e(route('addEmpRole')); ?>">
  <?php echo csrf_field(); ?>
      <h1>ADD EMPLOYEE ROLE</H1>
        <div class="form-group">
                  <label>Role</label>
                  <input type="text" class="form-control"  placeholder="Role" name="name">
        </div>
        <div >
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
  </div>
  <!-- /.content-wrapper -->
</div>
<!-- ./wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>