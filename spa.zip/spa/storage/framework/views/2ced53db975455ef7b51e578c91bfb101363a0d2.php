<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

 <?php $__env->startComponent('adminpages.navbar'); ?>
 <?php echo $__env->renderComponent(); ?>
  <!-- Left side column. contains the logo and sidebar -->
 
<?php $__env->startComponent('adminpages.sidebar'); ?>
 <?php echo $__env->renderComponent(); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
   

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
             <center> <h3> <b><class="box-title">EMPLOYEE LEAVE INFORMATION</b></h3></center>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <?php if(isset($info)): ?>
                <div class="alert-info alert">
                 <?php echo e($info); ?>

                </div>
              <?php endif; ?>
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr><th>EMPLOYEE NAME</th>
                  <th>LEAVE DATE</th>
                  <th>RESON FOR LEAVE</th>
                  <th>APPROVE</th>
                  <th>REJECT</th>
                </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                  <td><?php echo e($leave->fname); ?></td>
                  <td><?php echo e($leave->leavedate); ?></td>
                  <td><?php echo e($leave->reson); ?></td>
                  <td> <?php if($leave->status==0): ?>
                  <form action="<?php echo e(route('aprleave')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                        <input hidden name="id" value="<?php echo e($leave->id); ?>">
                        <button type="submit" name="aprleave" class="btn btn-primary" >APPROVE</button>
                    </form>
                    <?php elseif($leave->status==1): ?>
                        Approved
                    <?php endif; ?> 
                  </td>
                  
                  <td> <?php if($leave->status==0): ?>
                  <form action="<?php echo e(route('rejleave')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                        <input hidden name="id" value="<?php echo e($leave->id); ?>">
                        <button type="submit" name="rejleave" class="btn btn-primary" >REJECT</button>
                    </form>
                    <?php elseif($leave->status==2): ?>
                        Rejected
                    <?php endif; ?> 
                  </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

           <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>