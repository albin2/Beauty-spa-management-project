<div>
    Hi ,
    <h5> PAPAYA BEAUTY AND SPA</h5>

    <br><br>
    We can't process your package booking ,on your booking date<?php echo e($name); ?> 
    <p>you can cancel or reshedule your appointment through your account</p>
    <p>Thanku</p>
</div>