<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

 <?php $__env->startComponent('adminpages.navbar'); ?>
 <?php echo $__env->renderComponent(); ?>
  <!-- Left side column. contains the logo and sidebar -->
 
<?php $__env->startComponent('adminpages.sidebar'); ?>
 <?php echo $__env->renderComponent(); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
            <center><h3><b><class="box-title">BOOKING DETAILS</b></h3></center>
            </div>
            <!-- /.box-header -->
            <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>USER NAME</th>
                  <th>BOOOKING DATE</th>
                  <th>BOOKING TIME</th>
                  <th>PACKAGE NAME</th>
                  <th>EMPLOYEE NAME</th>
                  <th>AMOUNT</th>


                  <th>*</th>
                </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $apm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                  <td><?php echo e($row->usname); ?></td>
                  <td><?php echo e($row->bdate); ?></td>
                  <td><?php echo e($row->time); ?></td>
                  <td><?php echo e($row->servid); ?></td>
                  <td><?php echo e($row->duration); ?></td>
                  <td><?php echo e($row->amount); ?></td>
                  <td> <?php if($row->status==0): ?>
                        CANCELLED
                    <?php elseif($row->status==1): ?>
                        BOOCKED
                    <?php endif; ?> 
                  </td>
                  
               
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </tbody>
              </table>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

           <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>