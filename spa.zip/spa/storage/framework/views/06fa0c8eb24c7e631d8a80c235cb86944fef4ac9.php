 <?php $__env->startSection('content'); ?>
<div class="container"><div style="margin-top:-200px;">
<center><h2><b>VIEW APPOINTMENTS</b></h2></center></div>
    <div class="row justify-content-center my-5">
        <div class="col-md-8">
            <div class="root row">
            
            </div>
            <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>USER NAME</th>
                  <th>BOOOKING DATE</th>
                  <th>BOOKING TIME</th>
                  <th>PACKAGE NAME</th>
                  <th>AMOUNT</th>


                  <th>*</th>
                </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $apm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                  <td><?php echo e($row->usname); ?></td>
                  <td><?php echo e($row->bdate); ?></td>
                  <td><?php echo e($row->time); ?></td>
                  <td><?php echo e($row->servid); ?></td>
                  <td><?php echo e($row->amount); ?></td>
                  <td> <?php if($row->status==0): ?>
                        CANCELLED
                    <?php elseif($row->status==1): ?>
                        BOOCKED
                    <?php endif; ?> 
                  </td>
                  
               
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </tbody>
              </table>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.employee', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>