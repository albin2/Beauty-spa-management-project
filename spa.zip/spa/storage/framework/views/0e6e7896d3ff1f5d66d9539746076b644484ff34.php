<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

 <?php $__env->startComponent('adminpages.navbar'); ?>
 <?php echo $__env->renderComponent(); ?>
  <!-- Left side column. contains the logo and sidebar -->
 
<?php $__env->startComponent('adminpages.sidebar'); ?>
 <?php echo $__env->renderComponent(); ?>
<div class="content-wrapper">


<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
</style>
</head>
<body>

<center><h3><b><class="box-title">PACKAGE DATA LIST</b></h3></center>


<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for package......." title="Type in a name">

<table id="myTable">
<?php if(isset($info)): ?>
                <div class="alert-info alert">
                 <?php echo e($info); ?>

                </div>
              <?php endif; ?>
  <tr class="header"> 
                  <th>PACKAGE NAME</th>
                  <th>PRICE</th>
                  <th>TIME(Minutes)</th>
                  <th>DISCRIPTION</th>
                  <th>*</th>
                  <th>*</th>
                  <th>*</th>
  </tr>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
                  <td><?php echo e($row['packname']); ?></td>
                  <td><?php echo e($row['price']); ?></td>
                  <td><?php echo e($row['timed']); ?></td>
                  <td><?php echo e($row['packdecr']); ?></td>   
                  <td>
                  <?php if($row->status==1): ?>
                    <form action="<?php echo e(route('blockPackages')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                        <input hidden name="uid" value="<?php echo e($row['id']); ?>">
                        <button type="submit" name="blockPackages" class="btn btn-primary" >BLOCK</button>
                    </form>
                  <?php else: ?>
                    <form action="<?php echo e(route('unblockPackages')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                        <input hidden name="uid" value="<?php echo e($row['id']); ?>">
                        <button type="submit" name="blockPackages" class="btn btn-primary" > UN BLOCK</button>
                    </form>
                 <?php endif; ?>
                  </td>

                  <td>
                  <form action="<?php echo e(route('delPackages')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                        <input hidden name="uid" value="<?php echo e($row['id']); ?>">
                        <button type="submit" name="delPackages" class="btn btn-primary" >REMOVE</button>
                    </form>
                  </td>
                  <td>
                  <td>
                    <form action="<?php echo e(route('listpackageDetail')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                        <input hidden name="id" value="<?php echo e($row['id']); ?>">
                        <button type="submit" name="delPackages" class="btn btn-primary" >VIEW MORE</button>
                    </form>
                  </td>
                </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

</table>

<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

</body>
</html>

    <!-- Main content -->
    
    <!-- /.content -->
  </div>
  <?php $__env->stopSection(); ?>










   
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>