 <?php $__env->startSection('content'); ?>
<div class="container">
<div style="margin-top:50px;" class="box-title" ><center><h3><b>PACKAGES</b></h3></center>
            </div>
    <div class="row justify-content-center my-5">
        <div class="col-md-10">
            <div class="root row">
            <?php $__currentLoopData = $pack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card col-md-3">
                    <div class="card__header">
                        <h1><?php echo e($row['packname']); ?></h1>
                        <p class="price"><?php echo e($row['price']); ?>$</p>
                    </div>

                    <div class="card__body">
                        <ul class="features-list">
                            <!--<li>Start with 200 teams notes</li>
                            <li>Unlimited personal notes</li>-->
                            <li><i><h3>TIME REQUIRED <?php echo e($row['timed']); ?> MINUTES</h3></i></li>
                            <li>WELLNESS </li>
                        </ul>
                    </div>
                    <form class="login100-form validate-form" method="POST" action="<?php echo e(route('userEmployees')); ?>">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group">    
                        <input hidden name="sid" value="<?php echo e($row['servename']); ?>">
                        <input hidden name="pid" value="<?php echo e($row['id']); ?>">
                     <button type="submit" class="submit">Choose</button>
                 </div>
                 </form>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>