<?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/oh-autoval-style.css')); ?>">
<!-- Adding jQuery script. It must be before other script files -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"> </script>
<!-- Adding oh-autoVal script file -->
<script src="<?php echo e(asset('js/oh-autoval-script.js')); ?>"></script>

<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<hr>
<div class="container bootstrap snippet">
    <div class="row">
        <div class="col-sm-10">
        <span style="color:#e8eddf">   <h5>.</h5></span>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-3">
            <!--left col-->

            
            <div class="text-center">
                <img  class="avatar img-circle img-thumbnail" alt="avatar" src="<?php echo e(url('').'/storage/'.$row->image); ?>">
                <h6><?php echo e($row ->fname); ?> <?php echo e($row ->lname); ?></h6>
                
            </div>
            </hr><br>

        </div>
      
           
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!--/col-3-->
        <div class="col-sm-9">
            <ul class="nav nav-tabs">
           
            </ul>


            <div class="tab-content">
                
                <div class="tab-pane active" id="home">
                    <hr>
                    <form class="form oh-autoval-form" action="<?php echo e(route('changepassword')); ?>" method="post" id="registrationForm">
                     <?php echo csrf_field(); ?>
                     <?php if(isset($info)): ?>
            <div class="alert-info alert">
                <?php echo e($info); ?>

            </div>
            <?php endif; ?>
                        <div class="form-group">

                        <div class="cell-xs-12">
                                <label for="first_name">
                                <b><h6>Current Password</h6></b>
                                </label>
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 
                                <input type="password" class="form-control" id="current-password" name="current-password" placeholder="current-password" >
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-xs-6">
                                <label for="last_name">
                                <b><h6>New Password</h6></b>
                                </label>
                                <input type="password" class="form-control av-password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars " id="password" name="password" placeholder="New Password">
                            </div>
                        </div>

                        <div class="form-group">

                            <div class="col-xs-6">
                                <label for="phone">
                                   <b> <h6>Re-enter Password</h6></b>
                                </label>
                                <input type="password" class="form-control av-password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars" id="password_confirmation" name="password_confirmation" placeholder="Re-enter Password">
                            </div>
                        </div>

                        
                      
                     
                        <div class="form-group">
                            <div class="col-xs-12">
                            <span style="color:#e8eddf">   <h5>.</h5></span>
                            </div>
                        </div>
                        <div class="form-group">
                           <div class="col-xs-12">
                                <br>
                                <button class="btn btn-lg btn-success" type="submit">change password</button>
                                </div>
                      </div>
                    </form>

                    <hr>

                <!--/tab-pane-->
                
                <script src="<?php echo e(asset('profile/profile.js')); ?>"></script>

            </div>
            <!--/tab-pane-->
        </div>
        <!--/tab-content-->

    </div>
    <!--/col-9-->
</div>
<!--/row-->
</div>

<?php $__env->stopSection(); ?> 


























<?php echo $__env->make('layouts.employee', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>