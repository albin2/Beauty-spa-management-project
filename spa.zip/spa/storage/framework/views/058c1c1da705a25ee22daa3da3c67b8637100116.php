 <?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center my-5">
 <div class="box-header">
            <div class="box-title" ><center><h3><b>BOOKING DETAILS</b></h3></center>
            </div>
    
        <div class="col-md-8">
        
            <div class="root row">
            <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>BOOOKING DATE</th>
                  <th>BOOKING TIME</th>
                  <th>PACKAGE NAME</th>
                  <th>EMPLOYEE NAME</th>
                  <th>AMOUNT</th>


                  <th>*</th>
                </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $apm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                  <td><?php echo e($row->bdate); ?></td>
                  <td><?php echo e($row->time); ?></td>
                  <td><?php echo e($row->servid); ?></td>
                  <td><?php echo e($row->duration); ?></td>
                  <td><?php echo e($row->amount); ?></td>
                  
                  <td>
                    <form action="<?php echo e(route('canappo')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                        <input hidden name="id" value="<?php echo e($row->id); ?>">
                        <button type="submit" name="del" class="btn btn-primary" >CANCEL</button>
                    </form>
                  </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </tbody>
              </table>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>