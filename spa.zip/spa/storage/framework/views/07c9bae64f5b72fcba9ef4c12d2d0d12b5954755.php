<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

 <?php $__env->startComponent('adminpages.navbar'); ?>
 <?php echo $__env->renderComponent(); ?>
  <!-- Left side column. contains the logo and sidebar -->
 
  <?php $__env->startComponent('adminpages.sidebar'); ?>
 <?php echo $__env->renderComponent(); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  <form  method="POST" class="oh-autoval-form" enctype="multipart/form-data" action="<?php echo e(route('Product')); ?>" onsubmit="return">
  <?php echo csrf_field(); ?>
   <class ="box-body" >
              <center><h2><B>ADD PRODUCT DETAILS</B></h2></center>
              <div style="margin-left:100px;margin-right:100px;margin-top:20px;background-color: #e7e4e7;">

  <label><h4><b>PRODUCT CATEGEORY NAME</b></h4></label>
						<select name="categeory" class="form-control">
                <?php $__currentLoopData = $products1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($ser['id']); ?>"><?php echo e($ser['categeory']); ?></option> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
              
              </select>
   <div class="form-group">
    <label><h4><b>PRODUCT NAME</b></h4></label>
    <input type="text" class="form-control av-required" av-message="Required"name="productname"  placeholder="Product Name">
 </div>
 <div class="form-group">
    <label><h4><b>PRODUCT DESCRIPTION</b></h4></label>
    <textarea class="form-control av-required" av-message="required"  name="proddecr"  placeholder="Description"></textarea>
 </div>

 
 
 <div class="form-group">
    <label><h4><b>PRICE</b></h4></label>
    <input type="number" class="form-control av-price" av-message="invalid pricing format" name="price"  placeholder="price">
 </div>
 <div class="form-group">
    <label><h4><b>STOCK</b></h4></label>
    <input type="number" class="form-control av-posnumber" av-message="positive number" name="stock"  placeholder="stock details">
 </div>
 <div class="form-group">
    <label><h4><b>PICTURE</b></h4></label>
    <input type="file" class="form-control av-required"name="image"  placeholder="image" accept=".jpg,.jpeg,.png,.jfif">
 </div>
 <div style="margin-left:400px;" >
            <button type="submit" name="submit" class="btn btn-primary">ADD PRODUCT</button>
</div>
</div>
</div>

 </form>

   
  </div>
  <!-- /.content-wrapper -->
</div>
<!-- ./wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>