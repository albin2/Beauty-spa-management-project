<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

 <?php $__env->startComponent('adminpages.navbar'); ?>
 <?php echo $__env->renderComponent(); ?>
  <!-- Left side column. contains the logo and sidebar -->
 
<?php $__env->startComponent('adminpages.sidebar'); ?>
 <?php echo $__env->renderComponent(); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
  

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
            <center><h3><b> <class="box-title">EMPLOYEE DATA LIST</b></h3></center>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <?php if(isset($info)): ?>
                <div class="alert-info alert">
                 <?php echo e($info); ?>

                </div>
              <?php endif; ?>
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>NAME</th>
                  <th>DOB</th>
                  <th>CITY</th>
                  <th>CONTACT NUMBER</th>
                  <th>*</th>
                </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                  <td><?php echo e($row['fname']); ?></td>
                  <td><?php echo e($row['dob']); ?></td>
                  <td><?php echo e($row['city']); ?></td>
                  <td><?php echo e($row['number']); ?></td>
                  <td>
                    <form action="<?php echo e(route('delEmployees')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                        <input hidden name="uid" value="<?php echo e($row['id']); ?>">
                        <button type="submit" name="delEmployees" class="btn btn-primary" >Remove</button>
                    </form>
                  </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

           <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>