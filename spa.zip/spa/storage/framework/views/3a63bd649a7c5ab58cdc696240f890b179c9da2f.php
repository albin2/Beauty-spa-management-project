<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

 <?php $__env->startComponent('adminpages.navbar'); ?>
 <?php echo $__env->renderComponent(); ?>
  <!-- Left side column. contains the logo and sidebar -->
 
<?php $__env->startComponent('adminpages.sidebar'); ?>
 <?php echo $__env->renderComponent(); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->

 
    <html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
</style>
</head>
<body>

<center><h3><b><class="box-title">APPOINTMENT DETAILS</b></h3></center>


<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search Appointment date wise......." title="Type in a name">

<table id="myTable">
<?php if(isset($info)): ?>
                <div class="alert-info alert">
                 <?php echo e($info); ?>

                </div>
              <?php endif; ?>
  <tr class="header"> 
                  <th>BOOOKING DATE</th>
                  <th>USER NAME</th>
                  <th>BOOKING TIME</th>
                  <th>PACKAGE NAME</th>
                  <th>EMPLOYEE NAME</th>
                  <th>AMOUNT</th>
                  <th>*</th>

  </tr>

                  <?php $__currentLoopData = $apm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                  
                  <tr>
                  <td><?php echo e($row->bdate); ?></td>
                  <td><?php echo e($row->usname); ?></td>
                  <td><?php echo e($row->time); ?></td>
                  <td><?php echo e($row->servid); ?></td>
                  <td><?php echo e($row->duration); ?></td>
                  <td><?php echo e($row->amount); ?></td>
                  <td> <?php if($row->status==0): ?>
                  <span style="color:red"> <b>  CANCELLED</b></span>
                    <?php elseif($row->status==1): ?>
                    <span style="color:green"> <b> BOOCKED</b></span>
                    <?php endif; ?> 
                  </td>
                 
               
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                
                
                
   </table>

<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

</body>
</html>

    <!-- Main content -->
    
    <!-- /.content -->
  </div>
  <?php $__env->stopSection(); ?>
 
 
 
 
 
 
 
 
 
 
 
 
 
 

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>