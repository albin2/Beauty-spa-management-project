<?php $__env->startSection('content'); ?>
<footer class="page-footer page-footer-default">
              <div class="shell">
                <div class="range range-xs-center">
                  <div class="cell-lg-10"><a class="brand" href="index.html"><img src="images/logo-default-199x36.png" alt="" width="199" height="36"/></a>
                    <div class="text-highlighted-wrap">
                        <h1>About Us</h1>
                    <p>.............................................................................</p>
                    <p>.............................................................................</p>
                    <p class="large">Come and see us for a pain free laser hair removal treatment,
                         using Soprano XLi technology.We also offer silk or mink eyelash extensions in classic or dramatic styles, and yes we also do waxing!Our treatments are custom designed for each one of our guests. Our highly trained staff are here to satisfy with professionalism and expertise. Providing our clients with comfort and personal attention, leaving them feeling relaxed and rejuvenated</p>
                    
                    <p>.............................................................................</p>
                    <p>.............................................................................</p>
                        </div>
                    
                    <div class="divider divider-small divider-light block-centered"></div>
                  


                  </div>
                </div>
              </div>
            </footer>
</div>
            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guests', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>