<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

 <?php $__env->startComponent('adminpages.navbar'); ?>
 <?php echo $__env->renderComponent(); ?>
  <!-- Left side column. contains the logo and sidebar -->
 
<?php $__env->startComponent('adminpages.sidebar'); ?>
 <?php echo $__env->renderComponent(); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
</style>
</head>
<body>

<center><h3><b><class="box-title">BLOCKED USERS DATA LIST</b></h3><center>

<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for USERS.." title="Type in a name">

<table id="myTable">
<?php if(isset($info)): ?>
                <div class="alert-info alert">
                 <?php echo e($info); ?>

                </div>
              <?php endif; ?>
  <tr class="header"> 
    <th >EMAIL</th>
    <th >FIRST NAME</th>
    <th>LAST NAME</th>
    <th>CONTACT NUMBER</th>
        <th>*</th>
     <th>*</th>
  </tr>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr><td><?php echo e($row ->email); ?></td>
  <td><?php echo e($row ->fname); ?></td>
                  <td><?php echo e($row ->lname); ?></td>
                  <td><?php echo e($row ->contact); ?></td>
                  
                  
                  <td>
                    <form action="<?php echo e(route('delUser')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                        <input hidden name="uid" value="<?php echo e($row ->user_id); ?>">
                        <button type="submit" name="delUser" class="btn btn-primary" >REMOVE</button>
                    </form>
                  </td>

                  <td>
                    <form action="<?php echo e(route('unblockUser')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                        <input hidden name="uid" value="<?php echo e($row ->user_id); ?>">
                        <button type="submit" name="ublockUser" class="btn btn-primary" >UNBLOCK</button>
                    </form>
                  </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

</table>

<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

</body>
</html>



    <!-- Main content -->
    
    <!-- /.content -->
  </div>
  <?php $__env->stopSection(); ?>















    
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>