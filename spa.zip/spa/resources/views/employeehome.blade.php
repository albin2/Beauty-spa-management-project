@extends('layouts.employee') @section('content')
<div class="container">
    <h5><i>Welcome</i></h5>
<h4><i>Best Beauty And Spa</i> <span class="line"></span>
    </h4>
  
<video autoplay loop id="video-background" poster="" muted>
  <source src="css/honey.webm" type="video/webm">
</video>

    
</div>
@endsection