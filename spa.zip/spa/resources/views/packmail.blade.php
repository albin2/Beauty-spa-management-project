<div>
    Hi ,{{$usname}}
    <h5>PAPAYA BEAUTY AND SPA</h5>
    <br><br>
    <h3>Booking details</h3>
     Package  booking details
    <p>Package name:{{$packname}}</p>
    <p>Date:{{$bdates}}</p>
    <p>Time:{{$times}}</p>
    <p>Employee:{{$employee}}</p>
    <p>Thank you for choosing our service </p>

</div>