<div>
    Hi ,{{$usname}}
    <h5>BEAUTY AND SPA</h5>
    <br><br>
   
    <p>Your product booking id is BKPAPAYA{{$cartid}}</p>
      {{$bdt}}
    <p>Thanku for choosing our product.</p>

</div>