@extends('layouts.employee') @section('content')
<div class="container">
    <div class="row justify-content-center my-5">
        <div class="col-md-8">
            <div class="root row">
            
            </div>
        </div>
    </div>
</div>
</div>
@endsection