<div>
    Hi {{ $name }},
    <h5>WELCOME TO PAPAYA</h5>

    <br><br>
    Your Login Credentials:
    <p>Username: Your Email</p>
    <p>Password: {{ $key }}</p>
</div>