<div class="rd-navbar-wrap">
          <nav class="rd-navbar rd-navbar-default" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-sm-device-layout="rd-navbar-fixed" data-md-layout="rd-navbar-sidebar" data-md-device-layout="rd-navbar-fixed" data-lg-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-sidebar" data-stick-up-clone="false">
            <div class="rd-navbar-inner">
              <div class="rd-navbar-panel">
                <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                <div class="rd-navbar-brand"><a class="brand-name" href="#"><img src="images/logo-default-199x36.png" alt="" width="199" height="36"/></a></div>
              </div>
              <div class="rd-navbar-nav-wrap">
                <div class="rd-navbar-nav-inner">
                  <ul class="rd-navbar-nav">
                    <li class="active"><a href="/home">Home</a>                  
                    <li> 
                    <a href="{{ route('userEmployeessp') }}">Experts</a>
                    </li>
                    <li> 
                    <a href="{{ route('viewSpaaServices') }}">Spa services</a>
                    </li>
                    <li><a href="{{ route('viewUserproduct') }}">Shop</a>
                    </li>
                    <li><a href="{{ route('viewUserprofile') }}">Profile</a>
                    </li>
                    <li ><a href="/user/appointment/view">My appointments</a>                  
                    <li>
                    <li><a href="{{ route('viewuserproductbookings') }}">My bookings</a>
                    </li>
                    
                  </ul>
                  <div class="rd-navbar-nav-footer">
                  
                  </div>
                </div>
              </div>
            </div>
          </nav>
        </div>